-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 10-06-2010 a las 03:25:42
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `gestionvilar`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL,
  `data` text,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('bjf5oes7kk4t0naa72ns77oag4', 'Config|a:3:{s:9:"userAgent";s:32:"d56d79b9aab85e43e9427eed0c2378eb";s:4:"time";i:1276162782;s:7:"timeout";i:10;}Message|a:0:{}Auth|a:1:{s:4:"User";a:2:{s:2:"id";s:1:"1";s:8:"username";s:8:"alevilar";}}', 1276162782),
('0r93tvl9seu2agpe6rjs1apgg2', 'Config|a:3:{s:9:"userAgent";s:32:"d65da3b09bd83d81ac924aec2b98e099";s:4:"time";i:1276159350;s:7:"timeout";i:10;}Message|a:0:{}Auth|a:1:{s:4:"User";a:2:{s:2:"id";s:1:"1";s:8:"username";s:8:"alevilar";}}', 1276159351);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `county_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_localidades_departamentos1` (`county_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `cities`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `condominia`
--

CREATE TABLE IF NOT EXISTS `condominia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `porcentaje` float DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `calle` varchar(64) DEFAULT NULL,
  `numero_calle` varchar(45) DEFAULT NULL,
  `piso` varchar(45) DEFAULT NULL,
  `depto` varchar(45) DEFAULT NULL,
  `cp` varchar(45) DEFAULT NULL,
  `localidad` varchar(45) DEFAULT NULL,
  `departamento` varchar(45) DEFAULT NULL,
  `provincia` varchar(45) DEFAULT NULL,
  `identification_type_id` int(11) DEFAULT NULL,
  `identification_number` varchar(45) DEFAULT NULL,
  `nationality_type_id` varchar(45) DEFAULT NULL,
  `identification_authority` varchar(64) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `marital_status_id` int(11) DEFAULT NULL,
  `nupcia` int(11) DEFAULT NULL,
  `conyuge` varchar(64) DEFAULT NULL,
  `personeria_otorgada` varchar(64) DEFAULT NULL,
  `inscripcion` varchar(45) DEFAULT NULL,
  `fecha_inscripcion` date DEFAULT NULL,
  `apoderado_name` varchar(64) DEFAULT NULL,
  `apoderado_identification_type_id` varchar(45) DEFAULT NULL,
  `apoderado_identification_number` varchar(45) DEFAULT NULL,
  `apoderado_nationality_type` varchar(45) DEFAULT NULL,
  `apoderado_identification_auth` varchar(45) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `persona_fisica_o_juridica` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_condominia_customers1` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `condominia`
--

INSERT INTO `condominia` (`id`, `porcentaje`, `name`, `calle`, `numero_calle`, `piso`, `depto`, `cp`, `localidad`, `departamento`, `provincia`, `identification_type_id`, `identification_number`, `nationality_type_id`, `identification_authority`, `fecha_nacimiento`, `marital_status_id`, `nupcia`, `conyuge`, `personeria_otorgada`, `inscripcion`, `fecha_inscripcion`, `apoderado_name`, `apoderado_identification_type_id`, `apoderado_identification_number`, `apoderado_nationality_type`, `apoderado_identification_auth`, `customer_id`, `persona_fisica_o_juridica`) VALUES
(1, 45, 'Leyla Zorrilla', 'callecita', '2234', '2', 'B', '321B34', 'santa elena', 'villa calamuchita', 'Córdoba', 1, '10876239', NULL, 'de argentina', '1981-06-10', 1, 1, 'José Rodriguez', '', '', '2010-06-08', 'Soy el apoderado del condominio este', '1', '555353535', NULL, 'argentina', 0, ''),
(2, 20.3, 'Condominio Sanchez', 'callecita', '2234', '2', 'B', '321B34', 'santa elena', 'villa calamuchita', 'Córdoba', 2, '10876239', 'extranjero', 'de uruguay', '2010-06-09', 1, NULL, '', '', '', '2010-06-09', 'Soy el apoderado del condominio este', '1', '555353535', 'extranjero', 'brasil', 15, 'Jurídica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `counties`
--

CREATE TABLE IF NOT EXISTS `counties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_departamentos_jurisdicciones1` (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `counties`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL COMMENT 'me dice si es persona fisica o juridica',
  `name` varchar(200) NOT NULL,
  `born` date NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Volcar la base de datos para la tabla `customers`
--

INSERT INTO `customers` (`id`, `type`, `name`, `born`, `created`, `modified`) VALUES
(10, 'legal', 'pepe SRL', '2010-05-09', '2010-05-09 16:59:38', '2010-05-11 00:41:56'),
(13, 'legal', 'coco', '2010-05-09', '2010-05-09 18:38:46', '2010-05-09 18:40:37'),
(15, 'legal', 'Paxapoga de Riesco Antonio y Villano Salvador SRL De los Santuarios algo', '2010-05-11', '2010-05-11 20:30:14', '2010-06-10 02:21:08'),
(19, 'natural', 'Lily sarlanga', '2010-05-11', '2010-05-11 20:41:14', '2010-05-11 20:41:59'),
(20, 'natural', 'Washington Sarlanga', '2010-05-11', '2010-05-11 22:14:58', '2010-05-12 02:32:19'),
(21, 'legal', 'Empresa Loca SA', '2010-05-11', '2010-05-11 22:15:59', '2010-05-11 22:15:59'),
(22, 'legal', 'Coca Cola', '2008-05-07', '2010-05-11 22:17:32', '2010-05-28 04:18:24'),
(23, 'legal', 'as', '2010-05-15', '2010-05-15 14:37:44', '2010-05-15 14:42:09'),
(24, 'legal', 'Juridica 1', '2010-05-15', '2010-05-15 14:57:34', '2010-05-15 15:00:03'),
(25, 'legal', 'Juridica 2', '2010-05-15', '2010-05-15 15:28:17', '2010-05-15 15:28:17'),
(26, 'legal', 'Juridica 3', '2010-05-15', '2010-05-15 15:51:37', '2010-05-15 15:51:37'),
(27, 'legal', 'Juridica 4', '2010-05-15', '2010-05-15 15:53:09', '2010-05-15 15:53:09'),
(28, 'legal', 'Juridica 5', '2010-05-15', '2010-05-15 15:55:15', '2010-05-15 16:05:27'),
(29, 'natural', 'Carlitos Avella', '2010-05-28', '2010-05-28 03:19:00', '2010-05-28 03:19:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_homes`
--

CREATE TABLE IF NOT EXISTS `customer_homes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL COMMENT 'es para indicar el tipo de direccion, por ejemplo si es una direccion legal , comercial ou otro tipo',
  `city` varchar(100) DEFAULT NULL,
  `county` varchar(64) DEFAULT NULL,
  `state` varchar(64) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `floor` varchar(45) DEFAULT NULL,
  `apartment` varchar(45) DEFAULT NULL,
  `postal_code` varchar(45) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_domicilios_clientes1` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Volcar la base de datos para la tabla `customer_homes`
--

INSERT INTO `customer_homes` (`id`, `type`, `city`, `county`, `state`, `address`, `number`, `floor`, `apartment`, `postal_code`, `customer_id`) VALUES
(13, 'Legal', NULL, NULL, NULL, 'direccion 1 legal', '23', '', '', '', 10),
(14, 'Comercial', NULL, NULL, NULL, 'direccion 2 comercial', '33', '', '', '', 10),
(15, 'Guarda Habitual', NULL, NULL, NULL, 'direccion  4 GH', '333', '', '', '', 10),
(16, 'Legal', NULL, NULL, NULL, 'direccion legal 1', '23', '', '', '', 13),
(17, 'comercial', NULL, NULL, NULL, 'comercial 1', '344', '', '', '', 13),
(18, 'Guarda Habitual', NULL, NULL, NULL, 'direccion guarda habial 3', '344', '', '', '', 13),
(26, 'Legal', NULL, NULL, NULL, 'calle de la loca', '12122', '', '', '', 19),
(27, 'Legal', NULL, NULL, NULL, 'direccion legal 1de washington sarlanga', '23', '', '', '', 20),
(28, 'Legal', NULL, NULL, NULL, 'direccion legal 1 de empresa SA', 'SN', '', '', '', 21),
(30, 'Legal', 'Las Flores', NULL, NULL, 'una calle de las flores', '4444', '', '', '', 27),
(31, 'Legal', 'Las Flores 1', NULL, NULL, 'una calle de las flores', '2222', '', '', '', 28),
(32, 'Comercial', 'City Bell', NULL, NULL, 'Luolala', '22', '', '', '', 28),
(33, 'Guarda Habitual', 'Pepe', NULL, NULL, '233', '', '', '', '', 28),
(34, 'Legal', 'Las Flores', NULL, NULL, 'direccion loca', '2323', '', '', '', 22),
(35, 'Legal', 'Madariaga', 'Madariaga', 'Buenos Aires', 'Juan B. Justo', '2233', '2', 'F', '4321', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_legals`
--

CREATE TABLE IF NOT EXISTS `customer_legals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `inscription_entity` varchar(45) DEFAULT NULL,
  `inscription_number` varchar(45) DEFAULT NULL,
  `inscription_date` date DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_tipo_personas_clientes1` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Volcar la base de datos para la tabla `customer_legals`
--

INSERT INTO `customer_legals` (`id`, `customer_id`, `name`, `inscription_entity`, `inscription_number`, `inscription_date`, `created`, `modified`) VALUES
(6, 10, 'pepe SRL', 'ALGUIEN QUE ENTREGA PERSONERIAS', '28372hug3723h3', NULL, '2010-05-09 16:59:38', '2010-05-11 00:41:56'),
(9, 13, 'coco', '', '', NULL, '2010-05-09 18:38:47', '2010-05-09 18:40:37'),
(26, 15, 'Paxapoga de Riesco Antonio y Villano Salvador SRL De los Santuarios algo', 'la personeria que otorga', 'datos de inscripcion', NULL, '2010-05-11 20:30:15', '2010-06-10 02:21:08'),
(27, 21, 'Empresa Loca SA', 'una personeria', 'datos creacion', NULL, '2010-05-11 22:15:59', '2010-05-11 22:15:59'),
(28, 22, 'Coca Cola', 'otorgo la personeria', 'datos inscripcion', NULL, '2010-05-11 22:17:32', '2010-05-28 04:18:24'),
(29, 23, 'as', '', '', NULL, '2010-05-15 14:37:44', '2010-05-15 14:42:09'),
(30, 24, 'Juridica 1', '', '', NULL, '2010-05-15 14:57:34', '2010-05-15 14:57:34'),
(33, 25, 'Juridica 2', '', '', NULL, '2010-05-15 15:28:17', '2010-05-15 15:28:17'),
(34, 26, 'Juridica 3', '', '', NULL, '2010-05-15 15:51:37', '2010-05-15 15:51:37'),
(35, 27, 'Juridica 4', '', '', NULL, '2010-05-15 15:53:09', '2010-05-15 15:53:09'),
(36, 28, 'Juridica 5', 'personeria', 'datos numbers', NULL, '2010-05-15 15:55:15', '2010-05-15 16:05:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_naturals`
--

CREATE TABLE IF NOT EXISTS `customer_naturals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `surname` varchar(64) NOT NULL,
  `marital_status_id` int(11) DEFAULT NULL,
  `nuptials` varchar(45) DEFAULT NULL,
  `nationality_type` varchar(45) DEFAULT NULL,
  `nationality` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_clientes_estado_civiles` (`marital_status_id`),
  KEY `fk_tipo_personas_customers` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `customer_naturals`
--

INSERT INTO `customer_naturals` (`id`, `customer_id`, `first_name`, `surname`, `marital_status_id`, `nuptials`, `nationality_type`, `nationality`, `created`, `modified`) VALUES
(5, 19, 'Lily', 'sarlanga', NULL, '', NULL, NULL, '2010-05-11 20:41:14', '2010-05-11 20:41:59'),
(6, 20, 'Washington', 'Sarlanga', 1, '1', NULL, NULL, '2010-05-11 22:14:58', '2010-05-12 02:32:19'),
(7, 15, 'Jose Antonio de los Santos y Exclamatosos', 'Cornetti Rodriguez de Rosa Prieto', 1, '1', 'extranjero', 'Perú', '2010-05-18 01:51:44', '2010-06-10 01:58:14'),
(8, 29, 'Carlitos', 'Avella', NULL, '', 'argentino', '', '2010-05-28 03:19:00', '2010-05-28 03:19:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f01s`
--

CREATE TABLE IF NOT EXISTS `f01s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `representative_id` int(11) DEFAULT NULL,
  `solicitante` varchar(200) DEFAULT NULL,
  `se_certifica_obs` text,
  `observaciones` text,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `condominium_id` int(11) DEFAULT NULL,
  `spouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_f01s_vehicles1` (`vehicle_id`),
  KEY `fk_f01s_representatives1` (`representative_id`),
  KEY `fk_f01s_condominiums1` (`condominium_id`),
  KEY `fk_f01s_spouses1` (`spouse_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `f01s`
--

INSERT INTO `f01s` (`id`, `vehicle_id`, `representative_id`, `solicitante`, `se_certifica_obs`, `observaciones`, `created`, `modified`, `condominium_id`, `spouse_id`) VALUES
(1, 3, NULL, NULL, NULL, NULL, '2010-06-09 19:26:58', '2010-06-09 19:26:58', NULL, 1),
(2, 3, NULL, NULL, NULL, NULL, '2010-06-09 19:40:21', '2010-06-09 19:40:21', NULL, 1),
(3, 3, NULL, NULL, NULL, NULL, '2010-06-09 19:41:08', '2010-06-09 19:41:08', NULL, 1),
(4, 3, 5, NULL, NULL, NULL, '2010-06-09 19:45:10', '2010-06-09 19:45:10', 1, 1),
(5, 3, 5, NULL, NULL, NULL, '2010-06-09 19:45:25', '2010-06-09 19:45:25', 1, 1),
(6, 3, 5, NULL, 'observacion de arriba', 'observacion de abajo a la izquierd aescribo cosas para que se puedan imprimir y probar coomo salen.', '2010-06-09 21:38:55', '2010-06-09 21:38:55', 2, 1),
(7, 3, 5, NULL, 'observacion de arriba', 'observacion de abajo a la izquierd aescribo cosas para que se puedan imprimir y probar coomo salen.', '2010-06-10 01:31:52', '2010-06-10 01:31:52', 2, 1),
(8, 3, 5, NULL, 'observacion de arriba', 'observacion de abajo a la izquierd aescribo cosas para que se puedan imprimir y probar coomo salen.', '2010-06-10 01:32:10', '2010-06-10 01:32:10', 2, 1),
(9, 3, 5, NULL, 'observacion de arriba', 'observacion de abajo a la izquierd aescribo cosas para que se puedan imprimir y probar coomo salen.', '2010-06-10 01:39:07', '2010-06-10 01:39:07', 2, 1),
(10, 3, 5, NULL, 'observacion de arriba', 'observacion de abajo a la izquierd aescribo cosas para que se puedan imprimir y probar coomo salen.', '2010-06-10 01:41:54', '2010-06-10 01:41:54', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f02s`
--

CREATE TABLE IF NOT EXISTS `f02s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `declaraciones` text,
  `vehicle_id` int(11) NOT NULL,
  `representative_id` int(11) DEFAULT NULL,
  `solicitante` varchar(200) NOT NULL,
  `description` text,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_f02s_vehicles1` (`vehicle_id`),
  KEY `fk_f02s_representatives1` (`representative_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `f02s`
--

INSERT INTO `f02s` (`id`, `type`, `declaraciones`, `vehicle_id`, `representative_id`, `solicitante`, `description`, `created`, `modified`) VALUES
(1, '17', '', 6, NULL, 'Coca Cola', NULL, NULL, NULL),
(2, '17', '', 6, NULL, 'Coca Cola', NULL, NULL, NULL),
(3, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(4, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(5, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(6, '19', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(7, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(8, '19', 'otros trá,ites que no quiero hacerlos', 6, 6, 'Coca Cola', '', NULL, NULL),
(9, '19', 'más de 1 trámite no se puede', 6, 7, 'Coca Cola', '', NULL, NULL),
(10, '19', 'más de 1 trámite no se puede', 6, 7, 'Coca Cola', '', NULL, NULL),
(11, '19', 'más de 1 trámite no se puede', 6, 7, 'Coca Cola', '', NULL, NULL),
(12, '19', '', 6, 7, 'Coca Cola', '', NULL, NULL),
(13, '19', 'más de 1 trámite no se puede', 6, 6, 'Coca Cola', 'resto del nombre', NULL, NULL),
(14, '19', 'más de 1 trámite no se puede', 6, 6, 'Coca Cola', 'resto del nombre', NULL, NULL),
(15, '9', 'dullicado de certificado de baja vehiculo', 6, 7, 'Coca Cola', 'aca deberia seguri escribiendo el nombre en caso grande', NULL, NULL),
(16, '0', 'ds hfsiduhfs diugfhd ifhgdx fousdgf sduhgf sdufg sdufgsd iufgsdufgsdofhsdofhsdf uhsd fosdhgbf osdh fosdhf ', 3, 5, 'Jose Cornetti', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f11s`
--

CREATE TABLE IF NOT EXISTS `f11s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `datos` text,
  `representative_id` int(11) DEFAULT NULL,
  `nombre_del_conyuge` varchar(64) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `tipo_entrega` varchar(45) DEFAULT NULL COMMENT 'de posesion o de tenencia',
  `spouse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_f11s_vehicles1` (`vehicle_id`),
  KEY `fk_f11s_representatives1` (`representative_id`),
  KEY `fk_f11s_spouses1` (`spouse_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `f11s`
--

INSERT INTO `f11s` (`id`, `vehicle_id`, `datos`, `representative_id`, `nombre_del_conyuge`, `created`, `modified`, `tipo_entrega`, `spouse_id`) VALUES
(1, 3, 'Lorem ipsum ad his scripta blandit partiendo, eum fastidii accumsan euripidis in, eum liber hendrerit an. Qui ut wisi vocibus suscipiantur, quo dicit ridens inciderint id. Quo mundi lobortis reformidans eu, legimus senserit definiebas an eos. Eu sit tincidunt incorrupte definitionem.', 5, 'Del Bianco, Carola', '2010-06-10 00:36:05', '2010-06-10 00:36:05', 'posesion', 1),
(2, 3, 'Lorem ipsum ad his scripta blandit partiendo, eum fastidii accumsan euripidis in, eum liber hendrerit an. Qui ut wisi vocibus suscipiantur, quo dicit ridens inciderint id. Quo mundi lobortis reformidans eu, legimus senserit definiebas an eos. Eu sit tincidunt incorrupte definitionem.', 5, 'Del Bianco, Carola', '2010-06-10 00:37:02', '2010-06-10 00:37:02', 'posesion', 1),
(3, 3, 'Lorem ipsum ad his scripta blandit partiendo, eum fastidii accumsan euripidis in, eum liber hendrerit an. Qui ut wisi vocibus suscipiantur, quo dicit ridens inciderint id. Quo mundi lobortis reformidans eu, legimus senserit definiebas an eos. Eu sit tincidunt incorrupte definitionem.', 5, 'Del Bianco, Carola', '2010-06-10 00:44:03', '2010-06-10 00:44:03', 'posesion', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f12s`
--

CREATE TABLE IF NOT EXISTS `f12s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `observaciones` text,
  `lugar` varchar(50) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `nombre` varchar(64) DEFAULT NULL,
  `tipoynrodoc` varchar(45) DEFAULT NULL,
  `domicilio` varchar(45) DEFAULT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `localidad` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_f12_vehicles1` (`vehicle_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `f12s`
--

INSERT INTO `f12s` (`id`, `vehicle_id`, `observaciones`, `lugar`, `fecha`, `nombre`, `tipoynrodoc`, `domicilio`, `numero`, `localidad`, `created`, `modified`) VALUES
(1, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESNEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-08', 'solicitante', '1928912891', 'ajshjash9', '8877', 'lalalalalal', '2010-06-08 22:49:59', '2010-06-08 22:49:59'),
(2, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESNEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-08', 'solicitante', '1928912891', 'ajshjash9', '8877', 'lalalalalal', '2010-06-08 22:50:25', '2010-06-08 22:50:25'),
(3, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESNEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-08', 'solicitante', '1928912891', 'ajshjash9', '8877', 'lalalalalal', '2010-06-09 15:34:35', '2010-06-09 15:34:35'),
(4, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESNEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-08', 'solicitante', '1928912891', 'ajshjash9', '8877', 'lalalalalal', '2010-06-10 00:41:48', '2010-06-10 00:41:48'),
(5, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESNEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-08', 'solicitante', '1928912891', 'ajshjash9', '8877', 'lalalalalal', '2010-06-10 00:42:12', '2010-06-10 00:42:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `field_coordenates`
--

CREATE TABLE IF NOT EXISTS `field_coordenates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_creator_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `field_type_id` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `w` int(11) NOT NULL DEFAULT '0' COMMENT 'width',
  `h` int(11) NOT NULL DEFAULT '0' COMMENT 'height',
  `page` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_field_type_fcreators1` (`field_creator_id`),
  KEY `fk_field_type_field_types1` (`field_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=270 ;

--
-- Volcar la base de datos para la tabla `field_coordenates`
--

INSERT INTO `field_coordenates` (`id`, `field_creator_id`, `name`, `description`, `field_type_id`, `x`, `y`, `w`, `h`, `page`) VALUES
(1, 8, 'dominio', '', 2, 73, 45, 45, 5, 1),
(2, 8, 'MARCA', '', 1, 95, 74, 0, 0, 1),
(3, 8, 'TIPO', '', 1, 95, 80, 0, 0, 1),
(4, 8, 'MODELO', '', 1, 95, 86, 0, 0, 1),
(5, 8, 'MARCA MOTOR', '', 1, 95, 92, 0, 0, 1),
(6, 8, 'N° MOTOR', '', 1, 95, 98, 0, 0, 1),
(7, 8, 'MARCA CHASIS', '', 1, 95, 105, 0, 0, 1),
(8, 8, 'N° CHASIS', '', 1, 95, 111, 0, 0, 1),
(9, 8, 'OBSERVACIONES', 'FIJATE BIEN ESTA PORQ LA DIF DE RENGLONES ES DE 6MM Y LA LETRA Q FIGURA ACA MIDE 2,5MM ASI Q ACA SEGURO VAMOS A TENER Q PROBARLO UN PAR DE VECES', 3, 50, 130, 142, 6, 1),
(10, 8, 'LUGAR', '', 2, 48, 203, 46, 4, 1),
(11, 8, 'FECHA - DIA', '', 2, 102, 203, 8, 4, 1),
(12, 8, 'FECHA - MES', '', 2, 112, 203, 8, 4, 1),
(13, 8, 'FECHA - AÑO', '', 2, 122, 203, 8, 4, 1),
(14, 8, 'APELLIDO Y NOMBRE', '', 2, 92, 230, 102, 4, 1),
(15, 8, 'N° Y DNI', '', 1, 102, 239, 0, 0, 1),
(16, 8, 'CALLE', '', 2, 70, 242, 48, 4, 1),
(17, 8, 'N° ', '', 2, 125, 242, 23, 4, 1),
(18, 8, 'LOCALIDAD', '', 2, 154, 242, 40, 4, 1),
(19, 1, 'dominio', '', 2, 80, 47, 46, 5, 1),
(20, 1, 't  entero %', 'identificacion del titular', 2, 46, 70, 11, 4, 1),
(21, 1, 't decimal %', 'identificacion del titular', 2, 61, 70, 11, 4, 1),
(22, 1, 't nombre 1', '', 2, 46, 80, 71, 4, 1),
(23, 1, 't nombre 2', '', 2, 46, 89, 71, 4, 1),
(24, 1, 't nombre 3', 'aca irÃ­a el nÂ° de cuit', 1, 46, 99, 0, 0, 1),
(25, 1, 't calle', '', 2, 46, 106, 71, 4, 1),
(26, 1, 't numero', '', 2, 46, 114, 11, 4, 1),
(27, 1, 't piso', '', 2, 65, 114, 11, 4, 1),
(28, 1, 't depto', '', 2, 83, 114, 11, 4, 1),
(29, 1, 't cod postal', '', 2, 100, 114, 17, 4, 1),
(30, 1, 't localidad', '', 1, 46, 127, 0, 0, 1),
(31, 1, 't partido o depto', '', 1, 46, 135, 0, 0, 1),
(32, 1, 't provincia', '', 2, 94, 131, 24, 4, 1),
(33, 1, 't dni', 'marcar con una x', 2, 50, 147, 4, 3, 1),
(34, 1, 't l.e', 'marcar con una x', 2, 62, 147, 4, 3, 1),
(35, 1, 't l.c', 'marcar con una x', 2, 74, 147, 4, 3, 1),
(36, 1, 't extranjeros d.n.i', 'marcar con una x', 2, 90, 147, 4, 3, 1),
(37, 1, 't extranjerps c.i', 'marcar con una x', 2, 101, 147, 4, 3, 1),
(38, 1, 't extranjeros pasaporte', 'marcar con una x', 2, 112, 147, 4, 3, 1),
(39, 1, 't n° documento', '', 1, 45, 158, 0, 0, 1),
(40, 1, 't autoridad q lo expidio', '', 1, 78, 158, 0, 0, 1),
(41, 1, 't dia', 'fecha de nacimiento', 2, 46, 172, 5, 3, 1),
(42, 1, 't mes', 'fecha de nacimiento', 2, 55, 172, 5, 3, 1),
(43, 1, 't año', 'fecha de nacimiento', 2, 64, 172, 5, 3, 1),
(44, 1, 't soltero', 'marcar con una x', 2, 75, 172, 4, 3, 1),
(45, 1, 't casado', 'marcar con una x', 2, 85, 172, 4, 3, 1),
(46, 1, 't viudo', 'marcar con una x', 2, 94, 172, 4, 3, 1),
(47, 1, 't divorciado', 'marcar con una x', 2, 104, 172, 4, 3, 1),
(48, 1, 't nupcia', '', 2, 112, 172, 5, 3, 1),
(49, 1, 't nombre conyuge', '', 1, 46, 182, 0, 0, 1),
(50, 1, 't personeria', '', 1, 46, 194, 0, 0, 1),
(51, 1, 't datos de inscr', '', 1, 46, 207, 0, 0, 1),
(52, 1, 't diaa', '', 2, 90, 204, 5, 3, 1),
(53, 1, 't mess', '', 2, 99, 204, 5, 3, 1),
(54, 1, 't añoo', '', 2, 108, 204, 5, 3, 1),
(55, 1, 'n° cert automotor', '', 2, 64, 231, 54, 4, 1),
(56, 1, 'marca', '', 1, 54, 240, 0, 0, 1),
(57, 1, 'tipo', '', 1, 52, 246, 0, 0, 1),
(58, 1, 'modelo', '', 1, 55, 251, 0, 0, 1),
(59, 1, 'marca motor', '', 1, 62, 257, 0, 0, 1),
(60, 1, 'n° motor', '', 1, 61, 262, 0, 0, 1),
(61, 1, 'marca chasis', '', 1, 62, 268, 0, 0, 1),
(62, 1, 'carroceria', '', 1, 70, 273, 0, 0, 1),
(63, 1, 'uso', '', 1, 51, 279, 0, 0, 1),
(64, 1, 'c entero %', '', 2, 121, 70, 11, 4, 1),
(65, 1, 'c decimal %', '', 2, 137, 70, 11, 4, 1),
(66, 1, 'c nombre 1', '', 2, 121, 80, 71, 4, 1),
(67, 1, 'c nombre 2', '', 2, 121, 89, 71, 4, 1),
(68, 1, 'c nombre 3', 'cuit', 1, 121, 99, 0, 0, 1),
(69, 1, 'c calle', '', 2, 121, 106, 71, 4, 1),
(70, 1, 'c numero', '', 2, 121, 114, 11, 4, 1),
(71, 1, 'c piso', '', 2, 142, 114, 11, 4, 1),
(72, 1, 'c depto', '', 2, 158, 114, 11, 4, 1),
(73, 1, 'c cod postal', '', 2, 176, 114, 17, 4, 1),
(74, 1, 'c localidad', '', 1, 121, 127, 0, 0, 1),
(75, 1, 'c partido o depto', '', 1, 121, 135, 0, 0, 1),
(76, 1, 'c provincia', '', 2, 168, 131, 24, 4, 1),
(77, 1, 'c dni', '', 2, 126, 147, 4, 3, 1),
(78, 1, 'c l.e', '', 2, 138, 147, 4, 3, 1),
(79, 1, 'c l.c', '', 2, 150, 147, 4, 3, 1),
(80, 1, 'c extranjeros dni', '', 2, 165, 147, 4, 3, 1),
(81, 1, 'c extranjeros c.i', '', 2, 176, 147, 4, 3, 1),
(82, 1, 'c extranjeros pasaporte', '', 2, 187, 147, 4, 3, 1),
(83, 1, 'c documento', '', 1, 122, 158, 0, 0, 1),
(84, 1, 'c autoridad q lo expidio', '', 1, 154, 158, 0, 0, 1),
(85, 1, 'c dia', '', 2, 123, 172, 5, 3, 1),
(86, 1, 'c mes', '', 2, 131, 172, 5, 3, 1),
(87, 1, 'c año', '', 2, 140, 172, 5, 3, 1),
(88, 1, 'c soltero', '', 2, 151, 172, 4, 3, 1),
(89, 1, 'c casado', '', 2, 161, 172, 4, 3, 1),
(90, 1, 'c viudo', '', 2, 170, 172, 4, 3, 1),
(91, 1, 'c divorciado', '', 2, 179, 172, 4, 3, 1),
(92, 1, 'c nupcia', '', 2, 188, 172, 5, 3, 1),
(93, 1, 'c nombre conyuge', '', 1, 121, 182, 0, 0, 1),
(94, 1, 'c personeria', '', 1, 121, 194, 0, 0, 1),
(95, 1, 'c datos de inscrip', '', 1, 121, 207, 0, 0, 1),
(96, 1, 'c diaa', '', 2, 166, 204, 5, 3, 1),
(97, 1, 'c mess', '', 2, 175, 204, 5, 3, 1),
(98, 1, 'c añoo', '', 2, 183, 204, 5, 3, 1),
(99, 1, 'valor adq', '', 1, 125, 244, 0, 0, 1),
(100, 1, 'adq dia', '', 2, 166, 241, 5, 3, 1),
(101, 1, 'adq mes', '', 1, 175, 241, 5, 3, 1),
(102, 1, 'adq año', '', 1, 184, 241, 5, 3, 1),
(103, 1, 'elemento prob de adq', '', 1, 124, 258, 0, 0, 1),
(104, 1, 'se certifica...', 'de aca para adelante es la parte de atras del f 01', 3, 20, 30, 142, 4, 1),
(105, 1, 'fecha, sello ...', '', 1, 20, 68, 0, 0, 1),
(106, 1, 'tt apellido', '', 2, 17, 116, 68, 4, 1),
(107, 1, 'tt dni', '', 2, 52, 126, 3, 3, 2),
(108, 1, 'tt l.e', '', 2, 60, 126, 3, 3, 2),
(109, 1, 'tt l.c', '', 2, 67, 126, 3, 3, 2),
(110, 1, 'tt c.i', '', 2, 74, 126, 3, 3, 2),
(111, 1, 'tt pasaporte', '', 2, 81, 126, 3, 3, 2),
(112, 1, 'cc apellido', '', 2, 93, 116, 68, 4, 2),
(113, 1, 'cc dni', '', 2, 127, 126, 3, 3, 2),
(114, 1, 'cc l.e', '', 1, 135, 126, 3, 3, 2),
(115, 1, 'cc l.c', '', 2, 142, 126, 3, 3, 2),
(116, 1, 'cc c.i', '', 2, 149, 126, 3, 3, 2),
(117, 1, 'cc pasaporte', '', 2, 156, 126, 3, 3, 2),
(118, 1, 'tt numero', '', 1, 17, 137, 0, 0, 2),
(119, 1, 'tt autoridad', '', 1, 51, 137, 0, 0, 2),
(120, 1, 'cc numero', '', 1, 93, 137, 0, 0, 2),
(121, 1, 'cc autoridad', '', 1, 126, 137, 0, 0, 2),
(122, 1, 'tt fecha y sello', '', 1, 17, 159, 0, 0, 2),
(123, 1, 'cc fecha y sello', '', 1, 93, 159, 0, 0, 1),
(124, 1, 'observaciones', '', 3, 17, 172, 138, 5, 2),
(125, 7, 'dominio', '', 2, 82, 54, 42, 5, 1),
(126, 7, 'indicar datos...', '', 3, 46, 96, 58, 7, 1),
(127, 7, 'vendedor o trans', '', 2, 110, 87, 84, 5, 1),
(128, 7, 'soltero', '', 2, 129, 101, 5, 2, 1),
(129, 7, 'casado', '', 2, 138, 101, 5, 2, 1),
(130, 7, 'viudo', '', 2, 148, 101, 5, 2, 1),
(131, 7, 'divorciado', '', 2, 158, 101, 5, 2, 1),
(132, 7, 'apellido y nombre', '', 2, 110, 122, 83, 5, 1),
(133, 7, 'dni', '', 2, 142, 133, 5, 2, 1),
(134, 7, 'l.e', '', 2, 154, 133, 5, 2, 1),
(135, 7, 'l.c', '', 2, 165, 133, 5, 2, 1),
(136, 7, 'c.i', '', 2, 177, 133, 5, 2, 1),
(137, 7, ' pasaporte', '', 2, 188, 133, 5, 2, 1),
(138, 7, 'numero', '', 1, 109, 144, 0, 0, 1),
(139, 7, 'autoridad', '', 1, 143, 144, 0, 0, 1),
(140, 7, 'fecha, sello ...', '', 1, 110, 163, 0, 0, 1),
(141, 7, 'apellido y nombre', '', 2, 110, 177, 83, 5, 1),
(142, 7, 'apellido y nombre conyuge', '', 2, 110, 208, 83, 5, 1),
(143, 7, 'dni conyuge', '', 2, 142, 219, 5, 2, 1),
(144, 7, 'l.e conyuge', '', 2, 154, 219, 5, 2, 1),
(145, 7, 'l.c conyuge', '', 2, 165, 219, 5, 2, 1),
(146, 7, 'c.i conyuge', '', 2, 177, 219, 5, 2, 1),
(147, 7, 'pasaporte conyuge', '', 2, 188, 219, 5, 2, 1),
(148, 7, 'numero conyuge', '', 1, 109, 230, 0, 0, 1),
(149, 7, 'autoridad conyuge', '', 1, 143, 230, 0, 0, 1),
(150, 7, 'fecha y sello', '', 1, 110, 256, 0, 0, 1),
(151, 7, 'entrega posesion', '', 2, 47, 240, 2, 2, 1),
(152, 7, 'entrega tenencia', '', 2, 47, 251, 2, 2, 1),
(153, 3, 'dia', '', 2, 52, 43, 3, 3, 1),
(154, 3, 'mes', '', 2, 60, 43, 3, 3, 1),
(155, 3, 'año', '', 2, 68, 43, 3, 3, 1),
(156, 3, 'monto del contrato', '', 2, 46, 50, 34, 3, 1),
(157, 3, 'dominio', '', 2, 90, 48, 40, 5, 1),
(158, 3, 'a inscripcion', '', 1, 74, 70, 0, 0, 1),
(159, 3, 'a apellido 1', '', 2, 45, 74, 69, 4, 1),
(160, 3, 'd apellido 1', '', 2, 122, 74, 69, 4, 1),
(161, 3, 'a apellido 2', '', 2, 45, 82, 69, 4, 1),
(162, 3, 'd apellido 2', '', 2, 122, 82, 69, 4, 1),
(163, 3, 'a apellido 3 (cuit)', '', 2, 45, 87, 69, 4, 1),
(164, 3, 'd apellido 3 (cuil)', '', 2, 122, 87, 69, 4, 1),
(165, 3, 'a calle', '', 2, 45, 97, 69, 4, 1),
(166, 3, 'd calle', '', 2, 122, 97, 69, 4, 1),
(167, 3, 'a numero', '', 2, 45, 104, 18, 4, 1),
(168, 3, 'd numero', '', 2, 122, 104, 18, 4, 1),
(169, 3, 'a piso', '', 2, 67, 104, 11, 4, 1),
(170, 3, 'd piso', '', 2, 144, 104, 11, 4, 1),
(171, 3, 'a depto', '', 2, 82, 104, 11, 4, 1),
(172, 3, 'd depto', '', 2, 159, 104, 11, 4, 1),
(173, 3, 'a cod pos', '', 2, 97, 104, 18, 4, 1),
(174, 3, 'd cod pos', '', 2, 174, 104, 18, 4, 1),
(175, 3, 'a localidad', '', 2, 45, 112, 69, 4, 1),
(176, 3, 'd localidad', '', 2, 122, 112, 69, 4, 1),
(177, 3, 'a partido', '', 2, 45, 120, 42, 4, 1),
(178, 3, 'd partido', '', 2, 122, 120, 42, 4, 1),
(179, 3, 'a provincia', '', 2, 90, 120, 25, 4, 1),
(180, 3, 'd provincia', '', 2, 167, 120, 25, 4, 1),
(181, 3, 'a arg dni', '', 2, 50, 138, 3, 3, 1),
(182, 3, 'a arg le', '', 2, 61, 138, 3, 3, 1),
(183, 3, 'a arg lc', '', 2, 72, 138, 3, 3, 1),
(184, 3, 'a ext dni', '', 2, 88, 138, 3, 3, 1),
(185, 3, 'a ext ci', '', 2, 99, 138, 3, 3, 1),
(186, 3, 'a ext pas', '', 2, 109, 138, 3, 3, 1),
(187, 3, 'd arg dni', '', 2, 127, 138, 3, 3, 1),
(188, 3, 'd arg le', '', 2, 138, 138, 3, 3, 1),
(189, 3, 'd arg lc', '', 2, 144, 138, 3, 3, 1),
(190, 3, 'd ext dni', '', 2, 165, 138, 3, 3, 1),
(191, 3, 'd ext ci', '', 2, 176, 138, 3, 3, 1),
(192, 3, 'd ext pas', '', 2, 187, 138, 3, 3, 1),
(193, 3, 'a n doc', '', 1, 45, 149, 0, 0, 1),
(194, 3, 'd n doc', '', 1, 122, 149, 0, 0, 1),
(195, 3, 'a autoridad', '', 1, 74, 149, 0, 0, 1),
(196, 3, 'd autoridad', '', 1, 150, 149, 0, 0, 1),
(197, 3, 'a dia', '', 2, 44, 162, 4, 3, 1),
(198, 3, 'a mes', '', 2, 53, 162, 4, 3, 1),
(199, 3, 'a año', '', 2, 61, 162, 4, 3, 1),
(200, 3, 'a sol', '', 2, 72, 162, 4, 3, 1),
(201, 3, 'a casado', '', 2, 82, 162, 4, 3, 1),
(202, 3, 'a viudo', '', 2, 93, 162, 4, 3, 1),
(203, 3, 'a divor', '', 2, 103, 162, 4, 3, 1),
(204, 3, 'd dia', '', 2, 121, 162, 4, 3, 1),
(205, 3, 'd mes', '', 2, 130, 162, 4, 3, 1),
(206, 3, 'd año', '', 2, 138, 162, 4, 3, 1),
(207, 3, 'd sol', '', 2, 149, 162, 4, 3, 1),
(208, 3, 'd casado', '', 2, 159, 162, 4, 3, 1),
(209, 3, 'd viudo', '', 2, 170, 162, 4, 3, 1),
(210, 3, 'd divor', '', 2, 180, 162, 4, 3, 1),
(211, 3, 'a nupcia', '', 2, 111, 162, 4, 3, 1),
(212, 3, 'd nupcia', '', 2, 188, 162, 4, 3, 1),
(213, 3, 'a nombre', '', 2, 45, 170, 70, 4, 1),
(214, 3, 'd nombre', '', 2, 122, 170, 70, 4, 1),
(215, 3, 'a personeria', '', 2, 45, 179, 70, 4, 1),
(216, 3, 'd personeria', '', 2, 122, 179, 70, 4, 1),
(217, 3, 'a datos', '', 2, 45, 193, 42, 4, 1),
(218, 3, 'd datos', '', 2, 122, 193, 42, 4, 1),
(219, 3, 'a diaa', '', 2, 90, 193, 5, 4, 1),
(220, 3, 'a mess', '', 2, 100, 193, 5, 4, 1),
(221, 3, 'a añoo', '', 2, 110, 193, 5, 4, 1),
(222, 3, 'd diaa', '', 2, 167, 193, 5, 4, 1),
(223, 3, 'd mess', '', 2, 177, 193, 5, 4, 1),
(224, 3, 'd añoo', '', 2, 187, 193, 5, 4, 1),
(225, 3, 'g dominio', '', 2, 82, 233, 35, 4, 1),
(226, 3, 'g marca', '', 2, 57, 240, 60, 4, 1),
(227, 3, 'g tipo', '', 2, 57, 247, 60, 4, 1),
(228, 3, 'g modelo', '', 2, 60, 254, 58, 4, 1),
(229, 3, 'g marca motor', '', 2, 65, 261, 50, 4, 1),
(230, 3, 'g n motor', '', 2, 64, 268, 52, 4, 1),
(231, 3, 'g marca chasis', '', 2, 70, 275, 45, 4, 1),
(232, 3, 'g n chasis', '', 2, 63, 282, 52, 4, 1),
(233, 3, 'h solicitud si', '', 2, 150, 233, 5, 4, 1),
(234, 3, 'h solicitud no', '', 2, 161, 233, 5, 4, 1),
(235, 3, 'i clausula si', '', 2, 169, 265, 5, 4, 1),
(236, 3, 'i clausula no', '', 2, 181, 265, 5, 4, 1),
(237, 3, 'i grado', '', 2, 131, 269, 5, 4, 1),
(238, 3, 'i concepto saldo', '', 2, 169, 277, 5, 4, 1),
(239, 3, 'i concepto prestamo', '', 2, 181, 277, 5, 4, 1),
(240, 3, 'j seccional', 'aca empieza la parte de atras', 2, 12, 19, 87, 3, 1),
(241, 3, 'j dia', '', 2, 112, 19, 10, 3, 1),
(242, 3, 'j mes', '', 2, 131, 19, 37, 3, 1),
(243, 3, 'j año', '', 2, 18, 19, 14, 3, 1),
(244, 3, 'k lugar', '', 2, 30, 59, 67, 4, 1),
(245, 3, 'k mes', '', 2, 110, 59, 33, 4, 1),
(246, 3, 'k año', '', 2, 158, 59, 8, 4, 1),
(247, 3, 'l autorizo', '', 1, 30, 121, 0, 0, 1),
(248, 3, 'l dni', '', 1, 32, 126, 0, 0, 1),
(249, 3, 'm endoso', '', 1, 33, 168, 0, 0, 1),
(250, 3, 'm mes', '', 1, 67, 168, 0, 0, 1),
(251, 3, 'm año', '', 1, 96, 168, 0, 0, 1),
(252, 3, 'registro endoso', '', 1, 146, 168, 0, 0, 1),
(253, 3, 'm paguese', '', 1, 45, 173, 0, 0, 1),
(254, 3, 'registrado', '', 1, 143, 173, 0, 0, 1),
(255, 3, 'm domiciliado en', '', 1, 34, 179, 0, 0, 1),
(256, 3, 'a favor de', '', 1, 123, 179, 0, 0, 1),
(257, 3, 'm calle', '', 1, 19, 183, 0, 0, 1),
(258, 3, 'm n°', '', 1, 48, 183, 0, 0, 1),
(259, 3, 'libro registro', '', 1, 166, 183, 0, 0, 1),
(260, 3, 'n de..', '', 1, 16, 213, 0, 0, 1),
(261, 3, 'n del año...', '', 1, 48, 213, 0, 0, 1),
(262, 3, 'registro cancelacion dia', '', 1, 106, 228, 0, 0, 1),
(263, 3, 'registro cancelacion mes', '', 1, 122, 213, 0, 0, 1),
(264, 3, 'registro cancelacion año', '', 1, 186, 213, 0, 0, 1),
(265, 3, 'o traslado', '', 1, 37, 252, 0, 0, 1),
(266, 3, 'o mes', '', 1, 151, 213, 0, 0, 1),
(267, 3, 'o año', '', 1, 191, 252, 0, 0, 1),
(268, 3, 'o se tomo nota...', '', 3, 13, 258, 180, 4, 2),
(269, 3, 'o n°', '', 1, 110, 273, 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `field_creators`
--

CREATE TABLE IF NOT EXISTS `field_creators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `field_creators`
--

INSERT INTO `field_creators` (`id`, `name`) VALUES
(1, '01'),
(2, '02'),
(3, '03'),
(4, '04'),
(5, '05'),
(6, '08'),
(7, '11'),
(8, '12'),
(9, '13'),
(10, '13A'),
(11, '31'),
(12, '31A'),
(13, '31C'),
(14, '57'),
(15, '59'),
(16, '59M');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `field_types`
--

CREATE TABLE IF NOT EXISTS `field_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `field_types`
--

INSERT INTO `field_types` (`id`, `name`) VALUES
(1, 'Text'),
(2, 'xyCell'),
(3, 'xyMultiCell');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `identifications`
--

CREATE TABLE IF NOT EXISTS `identifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `identification_type_id` int(11) NOT NULL,
  `number` varchar(45) DEFAULT NULL,
  `authority_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_identificaciones_clientes1` (`customer_id`),
  KEY `fk_identifications_identification_types1` (`identification_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `identifications`
--

INSERT INTO `identifications` (`id`, `customer_id`, `identification_type_id`, `number`, `authority_name`) VALUES
(8, 13, 2, '30-542862213-1', ''),
(9, 10, 2, '30-542862213-1', 'UTORIDAD'),
(10, 20, 1, '30368326', ''),
(11, 21, 2, '30-542854444-4', 'iajsjas ijs'),
(12, 22, 2, '30-555552213-1', 'QUien expidio la autorizacion'),
(13, 28, 2, '30-48748784-1', ''),
(14, 15, 2, '33335544', 'autoridad qe expidio el DNI'),
(15, 29, 1, '888888888', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `identification_types`
--

CREATE TABLE IF NOT EXISTS `identification_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `identification_types`
--

INSERT INTO `identification_types` (`id`, `name`) VALUES
(1, 'DNI'),
(2, 'CUIT'),
(3, 'LE'),
(4, 'LC'),
(5, 'CI'),
(6, 'Pasaporte');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marital_statuses`
--

CREATE TABLE IF NOT EXISTS `marital_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `marital_statuses`
--

INSERT INTO `marital_statuses` (`id`, `name`) VALUES
(1, 'Casado'),
(2, 'Soltero'),
(3, 'Viudo'),
(4, 'Divorciado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representatives`
--

CREATE TABLE IF NOT EXISTS `representatives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `surname` varchar(45) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `nationality_type` varchar(45) DEFAULT NULL COMMENT 'aca simplemente dice si es extranjero o argentino',
  `nationality` varchar(45) DEFAULT NULL,
  `identification_type_id` int(11) DEFAULT NULL,
  `identification_number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_apoderados_clientes1` (`customer_id`),
  KEY `fk_representatives_identification_types1` (`identification_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `representatives`
--

INSERT INTO `representatives` (`id`, `name`, `surname`, `customer_id`, `nationality_type`, `nationality`, `identification_type_id`, `identification_number`) VALUES
(1, 'Pepe', 'Lolazz', 21, NULL, NULL, NULL, NULL),
(2, 'Guillermo', 'Coppola', 21, NULL, NULL, NULL, NULL),
(5, 'Lio', 'Messi', 15, 'extranjero', '', 1, '36092092'),
(6, 'apoderado  extranjero de coca', 'SAnchez', 22, 'extranjero', 'Paraguay', 6, '2323242424'),
(7, 'apoderado argento', 'Vivaldo', 22, 'argentino', '', 1, '232323');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spouses`
--

CREATE TABLE IF NOT EXISTS `spouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `identification_type_id` int(11) DEFAULT NULL,
  `identification_number` varchar(45) DEFAULT NULL,
  `identification_autority` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `customer_natural_id` int(11) NOT NULL,
  `born` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_spouses_customer_naturals` (`customer_natural_id`),
  KEY `fk_spouses_identification_types` (`identification_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `spouses`
--

INSERT INTO `spouses` (`id`, `name`, `identification_type_id`, `identification_number`, `identification_autority`, `created`, `modified`, `customer_natural_id`, `born`) VALUES
(1, 'Lobato, Zulma', 1, '23232323', '', '2010-05-18 01:53:32', '2010-06-04 03:42:50', 7, '2010-06-04'),
(2, 'MinujÃ­n, Marta', 1, '2122222', '', '2010-06-04 03:38:40', '2010-06-04 03:47:23', 7, '1990-06-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Volcar la base de datos para la tabla `states`
--

INSERT INTO `states` (`id`, `name`) VALUES
(1, 'BUENOS AIRES'),
(2, 'CATAMARCA'),
(3, 'CHACO'),
(4, 'CHUBUT'),
(5, 'CORDOBA'),
(6, 'CORRIENTES'),
(7, 'ENTRE RIOS'),
(8, 'FORMOSA'),
(9, 'JUJUY'),
(10, 'LA PAMPA'),
(11, 'LA RIOJA'),
(12, 'MENDOZA'),
(13, 'MISIONES'),
(14, 'NEUQUEN'),
(15, 'RIO NEGRO'),
(16, 'SALTA'),
(17, 'SAN JUAN'),
(18, 'SAN LUIS'),
(19, 'SANTA CRUZ'),
(20, 'SANTA FE'),
(21, 'SANTIAGO DEL ESTERO'),
(22, 'TIERRA DEL FUEGO'),
(23, 'TUCUMAN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'alevilar', '9a63fa90f02d7b9b269fd8069d7c37d16d2cb761'),
(2, 'dolores', '8884d78c9f5b0be703881e82612ff31cd7276f9c'),
(3, 'matias', '0bde20b7fab6c2f315c53f9689eb304c4a61432c');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehicles`
--

CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_type_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `fabrication_certificate` varchar(45) DEFAULT NULL,
  `brand` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  `motor_brand` varchar(45) DEFAULT NULL,
  `motor_number` varchar(45) DEFAULT NULL,
  `chasis_brand` varchar(45) DEFAULT NULL,
  `chasis_number` varchar(45) DEFAULT NULL,
  `use` varchar(150) DEFAULT NULL,
  `adquisition_value` varchar(45) DEFAULT NULL,
  `adquisition_date` date DEFAULT NULL,
  `adquisition_evidence_element` varchar(100) DEFAULT NULL,
  `patente` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vehiculos_clientes1` (`customer_id`),
  KEY `fk_vehicles_vehicle_type1` (`vehicle_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `vehicles`
--

INSERT INTO `vehicles` (`id`, `vehicle_type_id`, `customer_id`, `fabrication_certificate`, `brand`, `model`, `motor_brand`, `motor_number`, `chasis_brand`, `chasis_number`, `use`, `adquisition_value`, `adquisition_date`, `adquisition_evidence_element`, `patente`, `created`, `modified`, `type`) VALUES
(3, 2, 15, 'otro certificado mas', 'Fiat', 'Punto', 'marca motor', 'Motor number', 'marca chasis', 'numero chasis', 'ninguno', '', '2010-05-12', '', 'AFT-698', '2010-05-12 01:17:12', '2010-05-20 03:03:45', 'sedan 4 puertas'),
(4, 3, 15, 'otro certificado mas', 'ferguyson', '96', '', '', '', '', '', '', '2010-05-12', '', 'AAP-487', '2010-05-12 01:43:55', '2010-05-13 19:49:47', 'tractorsito'),
(5, 1, 10, 'certif', 'honda', '99', '', '', '', '', 'particular', '', '2010-05-13', '', '', '2010-05-13 19:58:08', '2010-06-02 13:33:04', '2 puertas'),
(6, 3, 22, 'otro certificado mas', 'ferguyson', 'FM 370 4x2', 'Fiat 2635', '823u2yh832', 'Torino', '9238j99jj3', 'fg 66', '', '2010-05-05', 'elemento probatorio', 'agt 376', '2010-05-15 18:48:41', '2010-05-28 04:09:34', 'SEDAN'),
(7, 3, 21, '01/00578373/2001', 'Volvo', 'FM 370 4x2', '', '', '', '', '', '', '2010-05-15', '', '999-STU', '2010-05-15 18:49:38', '2010-05-15 18:49:38', 'Tractor de Carretera'),
(8, 3, 15, 'IJSIDHISD', 'RENAULT', '76', '', '', '', '', '', '', '2010-05-15', '', '963 YHD', '2010-05-15 18:50:11', '2010-05-15 18:50:11', 'SEDAN'),
(9, 1, 24, '', '', '', '', '', '', '', '', '', '2010-05-15', '', '9873 JHSD', '2010-05-15 18:50:36', '2010-05-15 18:50:36', ''),
(10, 2, 25, '', '', '', '', '', '', '', '', '', '2010-05-15', '', '933 SDO', '2010-05-15 18:50:52', '2010-05-15 18:50:52', ''),
(11, 2, 24, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'POD 233', '2010-05-15 18:51:09', '2010-05-15 18:51:09', ''),
(12, 2, 25, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'OKD 3454', '2010-05-15 18:51:20', '2010-05-15 18:51:20', ''),
(13, 3, 26, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'III 983', '2010-05-15 18:51:35', '2010-05-15 18:51:35', ''),
(14, 3, 21, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'UHD 222', '2010-05-15 18:52:16', '2010-05-15 18:52:16', ''),
(15, 3, 21, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'jdk 653', '2010-05-15 18:58:43', '2010-05-17 00:40:05', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehicle_types`
--

CREATE TABLE IF NOT EXISTS `vehicle_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `image` longblob,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `vehicle_types`
--

INSERT INTO `vehicle_types` (`id`, `name`, `image`, `created`, `modified`) VALUES
(1, 'Moto', NULL, '2010-05-12 01:01:49', '2010-05-12 01:01:49'),
(2, 'Auto', NULL, '2010-05-12 01:01:56', '2010-05-12 01:01:56'),
(3, 'Maquinaria', NULL, '2010-05-12 01:02:02', '2010-05-12 01:02:02');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `fk_localidades_departamentos1` FOREIGN KEY (`county_id`) REFERENCES `counties` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `condominia`
--
ALTER TABLE `condominia`
  ADD CONSTRAINT `fk_condominia_customers1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `counties`
--
ALTER TABLE `counties`
  ADD CONSTRAINT `fk_departamentos_jurisdicciones1` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `customer_homes`
--
ALTER TABLE `customer_homes`
  ADD CONSTRAINT `fk_domicilios_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `customer_legals`
--
ALTER TABLE `customer_legals`
  ADD CONSTRAINT `fk_tipo_personas_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `customer_naturals`
--
ALTER TABLE `customer_naturals`
  ADD CONSTRAINT `fk_clientes_estado_civiles` FOREIGN KEY (`marital_status_id`) REFERENCES `marital_statuses` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tipo_personas_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `f01s`
--
ALTER TABLE `f01s`
  ADD CONSTRAINT `fk_f01s_condominiums1` FOREIGN KEY (`condominium_id`) REFERENCES `condominia` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f01s_representatives1` FOREIGN KEY (`representative_id`) REFERENCES `representatives` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f01s_spouses1` FOREIGN KEY (`spouse_id`) REFERENCES `spouses` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f01s_vehicles1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `f02s`
--
ALTER TABLE `f02s`
  ADD CONSTRAINT `fk_f02s_representatives1` FOREIGN KEY (`representative_id`) REFERENCES `representatives` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f02s_vehicles1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `f11s`
--
ALTER TABLE `f11s`
  ADD CONSTRAINT `fk_f11s_representatives1` FOREIGN KEY (`representative_id`) REFERENCES `representatives` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f11s_spouses1` FOREIGN KEY (`spouse_id`) REFERENCES `spouses` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f11s_vehicles1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `f12s`
--
ALTER TABLE `f12s`
  ADD CONSTRAINT `fk_f12_vehicles1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `field_coordenates`
--
ALTER TABLE `field_coordenates`
  ADD CONSTRAINT `fk_field_type_fcreators1` FOREIGN KEY (`field_creator_id`) REFERENCES `field_creators` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_field_type_field_types1` FOREIGN KEY (`field_type_id`) REFERENCES `field_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `identifications`
--
ALTER TABLE `identifications`
  ADD CONSTRAINT `fk_identificaciones_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_identifications_identification_types1` FOREIGN KEY (`identification_type_id`) REFERENCES `identification_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `representatives`
--
ALTER TABLE `representatives`
  ADD CONSTRAINT `fk_apoderados_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_representatives_identification_types1` FOREIGN KEY (`identification_type_id`) REFERENCES `identification_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `spouses`
--
ALTER TABLE `spouses`
  ADD CONSTRAINT `fk_spouses_customer_naturals` FOREIGN KEY (`customer_natural_id`) REFERENCES `customer_naturals` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_spouses_identification_types` FOREIGN KEY (`identification_type_id`) REFERENCES `identification_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `fk_vehicles_vehicle_type1` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vehiculos_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
