-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 02-06-2010 a las 03:37:36
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `gestionvilar`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL,
  `data` text,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('c5b8qkhvohtb2565dkgqv8hp02', 'Config|a:3:{s:9:"userAgent";s:32:"d56d79b9aab85e43e9427eed0c2378eb";s:4:"time";i:1275472023;s:7:"timeout";i:10;}Message|a:0:{}Auth|a:1:{s:4:"User";a:2:{s:2:"id";s:1:"1";s:8:"username";s:8:"alevilar";}}', 1275472024);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `county_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_localidades_departamentos1` (`county_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `cities`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `counties`
--

CREATE TABLE IF NOT EXISTS `counties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_departamentos_jurisdicciones1` (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `counties`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL COMMENT 'me dice si es persona fisica o juridica',
  `name` varchar(200) NOT NULL,
  `born` date NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Volcar la base de datos para la tabla `customers`
--

INSERT INTO `customers` (`id`, `type`, `name`, `born`, `created`, `modified`) VALUES
(10, 'legal', 'pepe SRL', '2010-05-09', '2010-05-09 16:59:38', '2010-05-11 00:41:56'),
(13, 'legal', 'coco', '2010-05-09', '2010-05-09 18:38:46', '2010-05-09 18:40:37'),
(15, 'natural', 'Jose Cornetti', '2010-05-11', '2010-05-11 20:30:14', '2010-06-02 01:17:52'),
(19, 'natural', 'Lily sarlanga', '2010-05-11', '2010-05-11 20:41:14', '2010-05-11 20:41:59'),
(20, 'natural', 'Washington Sarlanga', '2010-05-11', '2010-05-11 22:14:58', '2010-05-12 02:32:19'),
(21, 'legal', 'Empresa Loca SA', '2010-05-11', '2010-05-11 22:15:59', '2010-05-11 22:15:59'),
(22, 'legal', 'Coca Cola', '2008-05-07', '2010-05-11 22:17:32', '2010-05-28 04:18:24'),
(23, 'legal', 'as', '2010-05-15', '2010-05-15 14:37:44', '2010-05-15 14:42:09'),
(24, 'legal', 'Juridica 1', '2010-05-15', '2010-05-15 14:57:34', '2010-05-15 15:00:03'),
(25, 'legal', 'Juridica 2', '2010-05-15', '2010-05-15 15:28:17', '2010-05-15 15:28:17'),
(26, 'legal', 'Juridica 3', '2010-05-15', '2010-05-15 15:51:37', '2010-05-15 15:51:37'),
(27, 'legal', 'Juridica 4', '2010-05-15', '2010-05-15 15:53:09', '2010-05-15 15:53:09'),
(28, 'legal', 'Juridica 5', '2010-05-15', '2010-05-15 15:55:15', '2010-05-15 16:05:27'),
(29, 'natural', 'Carlitos Avella', '2010-05-28', '2010-05-28 03:19:00', '2010-05-28 03:19:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_homes`
--

CREATE TABLE IF NOT EXISTS `customer_homes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL COMMENT 'es para indicar el tipo de direccion, por ejemplo si es una direccion legal , comercial ou otro tipo',
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `floor` varchar(45) DEFAULT NULL,
  `apartment` varchar(45) DEFAULT NULL,
  `postal_code` varchar(45) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_domicilios_clientes1` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Volcar la base de datos para la tabla `customer_homes`
--

INSERT INTO `customer_homes` (`id`, `type`, `city`, `address`, `number`, `floor`, `apartment`, `postal_code`, `customer_id`) VALUES
(13, 'Legal', NULL, 'direccion 1 legal', '23', '', '', '', 10),
(14, 'Comercial', NULL, 'direccion 2 comercial', '33', '', '', '', 10),
(15, 'Guarda Habitual', NULL, 'direccion  4 GH', '333', '', '', '', 10),
(16, 'Legal', NULL, 'direccion legal 1', '23', '', '', '', 13),
(17, 'comercial', NULL, 'comercial 1', '344', '', '', '', 13),
(18, 'Guarda Habitual', NULL, 'direccion guarda habial 3', '344', '', '', '', 13),
(26, 'Legal', NULL, 'calle de la loca', '12122', '', '', '', 19),
(27, 'Legal', NULL, 'direccion legal 1de washington sarlanga', '23', '', '', '', 20),
(28, 'Legal', NULL, 'direccion legal 1 de empresa SA', 'SN', '', '', '', 21),
(30, 'Legal', 'Las Flores', 'una calle de las flores', '4444', '', '', '', 27),
(31, 'Legal', 'Las Flores 1', 'una calle de las flores', '2222', '', '', '', 28),
(32, 'Comercial', 'City Bell', 'Luolala', '22', '', '', '', 28),
(33, 'Guarda Habitual', 'Pepe', '233', '', '', '', '', 28),
(34, 'Legal', 'Las Flores', 'direccion loca', '2323', '', '', '', 22),
(35, 'Legal', 'City Bell', 'Juan B. Justo', '2233', '2', 'F', '4321', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_legals`
--

CREATE TABLE IF NOT EXISTS `customer_legals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `inscription_entity` varchar(45) DEFAULT NULL,
  `inscription_number` varchar(45) DEFAULT NULL,
  `inscription_date` date DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_tipo_personas_clientes1` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Volcar la base de datos para la tabla `customer_legals`
--

INSERT INTO `customer_legals` (`id`, `customer_id`, `name`, `inscription_entity`, `inscription_number`, `inscription_date`, `created`, `modified`) VALUES
(6, 10, 'pepe SRL', 'ALGUIEN QUE ENTREGA PERSONERIAS', '28372hug3723h3', NULL, '2010-05-09 16:59:38', '2010-05-11 00:41:56'),
(9, 13, 'coco', '', '', NULL, '2010-05-09 18:38:47', '2010-05-09 18:40:37'),
(26, 15, '', NULL, NULL, NULL, '2010-05-11 20:30:15', '2010-05-11 20:30:15'),
(27, 21, 'Empresa Loca SA', 'una personeria', 'datos creacion', NULL, '2010-05-11 22:15:59', '2010-05-11 22:15:59'),
(28, 22, 'Coca Cola', 'otorgo la personeria', 'datos inscripcion', NULL, '2010-05-11 22:17:32', '2010-05-28 04:18:24'),
(29, 23, 'as', '', '', NULL, '2010-05-15 14:37:44', '2010-05-15 14:42:09'),
(30, 24, 'Juridica 1', '', '', NULL, '2010-05-15 14:57:34', '2010-05-15 14:57:34'),
(33, 25, 'Juridica 2', '', '', NULL, '2010-05-15 15:28:17', '2010-05-15 15:28:17'),
(34, 26, 'Juridica 3', '', '', NULL, '2010-05-15 15:51:37', '2010-05-15 15:51:37'),
(35, 27, 'Juridica 4', '', '', NULL, '2010-05-15 15:53:09', '2010-05-15 15:53:09'),
(36, 28, 'Juridica 5', 'personeria', 'datos numbers', NULL, '2010-05-15 15:55:15', '2010-05-15 16:05:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer_naturals`
--

CREATE TABLE IF NOT EXISTS `customer_naturals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `surname` varchar(64) NOT NULL,
  `marital_status_id` int(11) DEFAULT NULL,
  `nuptials` varchar(45) DEFAULT NULL,
  `nationality_type` varchar(45) DEFAULT NULL,
  `nationality` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_clientes_estado_civiles` (`marital_status_id`),
  KEY `fk_tipo_personas_customers` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `customer_naturals`
--

INSERT INTO `customer_naturals` (`id`, `customer_id`, `first_name`, `surname`, `marital_status_id`, `nuptials`, `nationality_type`, `nationality`, `created`, `modified`) VALUES
(5, 19, 'Lily', 'sarlanga', NULL, '', NULL, NULL, '2010-05-11 20:41:14', '2010-05-11 20:41:59'),
(6, 20, 'Washington', 'Sarlanga', 1, '1', NULL, NULL, '2010-05-11 22:14:58', '2010-05-12 02:32:19'),
(7, 15, 'Jose', 'Cornetti', 1, '1', 'argentino', '', '2010-05-18 01:51:44', '2010-06-02 01:17:52'),
(8, 29, 'Carlitos', 'Avella', NULL, '', 'argentino', '', '2010-05-28 03:19:00', '2010-05-28 03:19:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f02s`
--

CREATE TABLE IF NOT EXISTS `f02s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `declaraciones` text,
  `vehicle_id` int(11) NOT NULL,
  `representative_id` int(11) DEFAULT NULL,
  `solicitante` varchar(200) NOT NULL,
  `description` text,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_f02s_vehicles1` (`vehicle_id`),
  KEY `fk_f02s_representatives1` (`representative_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `f02s`
--

INSERT INTO `f02s` (`id`, `type`, `declaraciones`, `vehicle_id`, `representative_id`, `solicitante`, `description`, `created`, `modified`) VALUES
(1, '17', '', 6, NULL, 'Coca Cola', NULL, NULL, NULL),
(2, '17', '', 6, NULL, 'Coca Cola', NULL, NULL, NULL),
(3, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(4, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(5, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(6, '19', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(7, '20', 'otros trámites locossss', 6, 6, 'Coca Cola', '', NULL, NULL),
(8, '19', 'otros trá,ites que no quiero hacerlos', 6, 6, 'Coca Cola', '', NULL, NULL),
(9, '19', 'más de 1 trámite no se puede', 6, 7, 'Coca Cola', '', NULL, NULL),
(10, '19', 'más de 1 trámite no se puede', 6, 7, 'Coca Cola', '', NULL, NULL),
(11, '19', 'más de 1 trámite no se puede', 6, 7, 'Coca Cola', '', NULL, NULL),
(12, '19', '', 6, 7, 'Coca Cola', '', NULL, NULL),
(13, '19', 'más de 1 trámite no se puede', 6, 6, 'Coca Cola', 'resto del nombre', NULL, NULL),
(14, '19', 'más de 1 trámite no se puede', 6, 6, 'Coca Cola', 'resto del nombre', NULL, NULL),
(15, '9', 'dullicado de certificado de baja vehiculo', 6, 7, 'Coca Cola', 'aca deberia seguri escribiendo el nombre en caso grande', NULL, NULL),
(16, '0', 'ds hfsiduhfs diugfhd ifhgdx fousdgf sduhgf sdufg sdufgsd iufgsdufgsdofhsdofhsdf uhsd fosdhgbf osdh fosdhf ', 3, 5, 'Jose Cornetti', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f12s`
--

CREATE TABLE IF NOT EXISTS `f12s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `observaciones` text,
  `lugar` varchar(50) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_f12_vehicles1` (`vehicle_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Volcar la base de datos para la tabla `f12s`
--

INSERT INTO `f12s` (`id`, `vehicle_id`, `observaciones`, `lugar`, `fecha`, `created`, `modified`) VALUES
(3, 3, 'una observa', 'un lugar', '2010-06-01', NULL, NULL),
(4, 3, 'otra observación pero esta vez con acento', 'otro lugar más', '2010-06-01', NULL, NULL),
(5, 4, 'He verificado personalmente la autenticidad de los datos que figuran en el presente formulrio y me hago personalmente responsable civil y criminalmente por los errores u omicionesen que pudiera incurrir, sin prejuicio de las que a la empresa le correspondan.', 'Cañuelas', '2010-06-02', NULL, NULL),
(6, 4, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', 'Cañuelas', '2010-06-02', NULL, NULL),
(7, 10, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-02', '2010-06-02 02:05:38', '2010-06-02 02:05:38'),
(8, 8, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', '', '2010-06-02', '2010-06-02 02:18:51', '2010-06-02 02:18:51'),
(9, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', 'un lugar', '2010-06-18', '2010-06-02 02:24:15', '2010-06-02 02:24:15'),
(10, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', 'un lugar', '2010-06-18', '2010-06-02 02:29:06', '2010-06-02 02:29:06'),
(11, 3, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', 'un lugar', '2010-06-18', '2010-06-02 03:05:06', '2010-06-02 03:05:06'),
(12, 4, 'HE VERIFICADO PERSONALMENTE LA AUTENTICIDAD DE LOS DATOS QUE FIGURAN EN EL PRESENTE FORMULARIO Y ME HAGO PERSONALMENTE RESPONSABLE CIVIL Y CRIMINALMENTE POR LOS ERRORES U OMICIONESEN QUE PUDIERA INCURRIR, SIN PREJUICIO DE LAS QUE A LA EMPRESA LE CORRESPONDAN.', 'Cañuelas', '2010-06-02', '2010-06-02 03:19:25', '2010-06-02 03:19:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `field_coordenates`
--

CREATE TABLE IF NOT EXISTS `field_coordenates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_creator_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `field_type_id` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `w` int(11) NOT NULL DEFAULT '0' COMMENT 'width',
  `h` int(11) NOT NULL DEFAULT '0' COMMENT 'height',
  PRIMARY KEY (`id`),
  KEY `fk_field_type_fcreators1` (`field_creator_id`),
  KEY `fk_field_type_field_types1` (`field_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Volcar la base de datos para la tabla `field_coordenates`
--

INSERT INTO `field_coordenates` (`id`, `field_creator_id`, `name`, `description`, `field_type_id`, `x`, `y`, `w`, `h`) VALUES
(1, 8, 'dominio', '', 2, 73, 45, 5, 45),
(2, 8, 'MARCA', '', 1, 95, 74, 0, 0),
(3, 8, 'TIPO', '', 1, 95, 80, 0, 0),
(4, 8, 'MODELO', '', 1, 95, 86, 0, 0),
(5, 8, 'MARCA MOTOR', '', 1, 95, 92, 0, 0),
(6, 8, 'N° MOTOR', '', 1, 95, 98, 0, 0),
(7, 8, 'MARCA CHASIS', '', 1, 95, 105, 0, 0),
(8, 8, 'N° CHASIS', '', 1, 95, 111, 0, 0),
(9, 8, 'OBSERVACIONES', 'FIJATE BIEN ESTA PORQ LA DIF DE RENGLONES ES DE 6MM Y LA LETRA Q FIGURA ACA MIDE 2,5MM ASI Q ACA SEGURO VAMOS A TENER Q PROBARLO UN PAR DE VECES', 3, 50, 130, 142, 6),
(10, 8, 'LUGAR', '', 2, 48, 203, 46, 4),
(11, 8, 'FECHA - DIA', '', 2, 102, 203, 8, 4),
(12, 8, 'FECHA - MES', '', 2, 112, 203, 8, 4),
(13, 8, 'FECHA - AÑO', '', 2, 122, 203, 8, 4),
(14, 8, 'APELLIDO Y NOMBRE', '', 2, 92, 230, 102, 4),
(15, 8, 'N° Y DNI', '', 1, 102, 239, 0, 0),
(16, 8, 'CALLE', '', 2, 70, 242, 48, 4),
(17, 8, 'N°', '', 2, 125, 242, 23, 4),
(18, 8, 'LOCALIDAD', '', 2, 154, 242, 40, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `field_creators`
--

CREATE TABLE IF NOT EXISTS `field_creators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `field_creators`
--

INSERT INTO `field_creators` (`id`, `name`) VALUES
(1, '01'),
(2, '02'),
(3, '03'),
(4, '04'),
(5, '05'),
(6, '08'),
(7, '11'),
(8, '12'),
(9, '13'),
(10, '13A'),
(11, '31'),
(12, '31A'),
(13, '31C'),
(14, '57'),
(15, '59'),
(16, '59M');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `field_types`
--

CREATE TABLE IF NOT EXISTS `field_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `field_types`
--

INSERT INTO `field_types` (`id`, `name`) VALUES
(1, 'Text'),
(2, 'xyCell'),
(3, 'xyMultiCell');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `identifications`
--

CREATE TABLE IF NOT EXISTS `identifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `identification_type_id` int(11) NOT NULL,
  `number` varchar(45) DEFAULT NULL,
  `authority_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_identificaciones_clientes1` (`customer_id`),
  KEY `fk_identifications_identification_types1` (`identification_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `identifications`
--

INSERT INTO `identifications` (`id`, `customer_id`, `identification_type_id`, `number`, `authority_name`) VALUES
(8, 13, 2, '30-542862213-1', ''),
(9, 10, 2, '30-542862213-1', 'UTORIDAD'),
(10, 20, 1, '30368326', ''),
(11, 21, 2, '30-542854444-4', 'iajsjas ijs'),
(12, 22, 2, '30-555552213-1', 'QUien expidio la autorizacion'),
(13, 28, 2, '30-48748784-1', ''),
(14, 15, 1, '33335544', 'autoridad qe expidio el DNI'),
(15, 29, 1, '888888888', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `identification_types`
--

CREATE TABLE IF NOT EXISTS `identification_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `identification_types`
--

INSERT INTO `identification_types` (`id`, `name`) VALUES
(1, 'DNI'),
(2, 'CUIT'),
(3, 'LE'),
(4, 'LC'),
(5, 'CI'),
(6, 'Pasaporte');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marital_statuses`
--

CREATE TABLE IF NOT EXISTS `marital_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `marital_statuses`
--

INSERT INTO `marital_statuses` (`id`, `name`) VALUES
(1, 'Casado'),
(2, 'Soltero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representatives`
--

CREATE TABLE IF NOT EXISTS `representatives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `surname` varchar(45) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `nationality_type` varchar(45) DEFAULT NULL COMMENT 'aca simplemente dice si es extranjero o argentino',
  `nationality` varchar(45) DEFAULT NULL,
  `identification_type_id` int(11) DEFAULT NULL,
  `identification_number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_apoderados_clientes1` (`customer_id`),
  KEY `fk_representatives_identification_types1` (`identification_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `representatives`
--

INSERT INTO `representatives` (`id`, `name`, `surname`, `customer_id`, `nationality_type`, `nationality`, `identification_type_id`, `identification_number`) VALUES
(1, 'Pepe', 'Lolazz', 21, NULL, NULL, NULL, NULL),
(2, 'Guillermo', 'Coppola', 21, NULL, NULL, NULL, NULL),
(5, 'Lio', 'Messi', 15, 'extranjero', '', 1, '36092092'),
(6, 'apoderado  extranjero de coca', 'SAnchez', 22, 'extranjero', 'Paraguay', 6, '2323242424'),
(7, 'apoderado argento', 'Vivaldo', 22, 'argentino', '', 1, '232323');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `spouses`
--

CREATE TABLE IF NOT EXISTS `spouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `identification_type_id` int(11) DEFAULT NULL,
  `identification_number` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `customer_natural_id` int(11) NOT NULL,
  `born` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_spouses_customer_naturals` (`customer_natural_id`),
  KEY `fk_spouses_identification_types` (`identification_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `spouses`
--

INSERT INTO `spouses` (`id`, `name`, `identification_type_id`, `identification_number`, `created`, `modified`, `customer_natural_id`, `born`) VALUES
(1, 'Miriam Galápagos', 1, '23232323', '2010-05-18 01:53:32', '2010-05-18 16:20:28', 7, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Volcar la base de datos para la tabla `states`
--

INSERT INTO `states` (`id`, `name`) VALUES
(1, 'BUENOS AIRES'),
(2, 'CATAMARCA'),
(3, 'CHACO'),
(4, 'CHUBUT'),
(5, 'CORDOBA'),
(6, 'CORRIENTES'),
(7, 'ENTRE RIOS'),
(8, 'FORMOSA'),
(9, 'JUJUY'),
(10, 'LA PAMPA'),
(11, 'LA RIOJA'),
(12, 'MENDOZA'),
(13, 'MISIONES'),
(14, 'NEUQUEN'),
(15, 'RIO NEGRO'),
(16, 'SALTA'),
(17, 'SAN JUAN'),
(18, 'SAN LUIS'),
(19, 'SANTA CRUZ'),
(20, 'SANTA FE'),
(21, 'SANTIAGO DEL ESTERO'),
(22, 'TIERRA DEL FUEGO'),
(23, 'TUCUMAN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'alevilar', '9a63fa90f02d7b9b269fd8069d7c37d16d2cb761'),
(2, 'dolores', '8884d78c9f5b0be703881e82612ff31cd7276f9c'),
(3, 'matias', '0bde20b7fab6c2f315c53f9689eb304c4a61432c');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehicles`
--

CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_type_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `fabrication_certificate` varchar(45) DEFAULT NULL,
  `brand` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  `motor_brand` varchar(45) DEFAULT NULL,
  `motor_number` varchar(45) DEFAULT NULL,
  `chasis_brand` varchar(45) DEFAULT NULL,
  `chasis_number` varchar(45) DEFAULT NULL,
  `use` varchar(150) DEFAULT NULL,
  `adquisition_value` varchar(45) DEFAULT NULL,
  `adquisition_date` date DEFAULT NULL,
  `adquisition_evidence_element` varchar(100) DEFAULT NULL,
  `patente` varchar(45) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vehiculos_clientes1` (`customer_id`),
  KEY `fk_vehicles_vehicle_type1` (`vehicle_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `vehicles`
--

INSERT INTO `vehicles` (`id`, `vehicle_type_id`, `customer_id`, `fabrication_certificate`, `brand`, `model`, `motor_brand`, `motor_number`, `chasis_brand`, `chasis_number`, `use`, `adquisition_value`, `adquisition_date`, `adquisition_evidence_element`, `patente`, `created`, `modified`, `type`) VALUES
(3, 2, 15, 'otro certificado mas', 'Fiat', 'Punto', 'marca motor', 'Motor number', 'marca chasis', 'numero chasis', 'ninguno', '', '2010-05-12', '', 'AFT-698', '2010-05-12 01:17:12', '2010-05-20 03:03:45', 'sedan 4 puertas'),
(4, 3, 15, 'otro certificado mas', 'ferguyson', '96', '', '', '', '', '', '', '2010-05-12', '', 'AAP-487', '2010-05-12 01:43:55', '2010-05-13 19:49:47', 'tractorsito'),
(5, 1, 10, 'certif', 'honda', '99', '', '', '', '', 'particular', '', '2010-05-13', '', '', '2010-05-13 19:58:08', '2010-05-13 19:58:08', '2 puertas'),
(6, 3, 22, 'otro certificado mas', 'ferguyson', 'FM 370 4x2', 'Fiat 2635', '823u2yh832', 'Torino', '9238j99jj3', 'fg 66', '', '2010-05-05', 'elemento probatorio', 'agt 376', '2010-05-15 18:48:41', '2010-05-28 04:09:34', 'SEDAN'),
(7, 3, 21, '01/00578373/2001', 'Volvo', 'FM 370 4x2', '', '', '', '', '', '', '2010-05-15', '', '999-STU', '2010-05-15 18:49:38', '2010-05-15 18:49:38', 'Tractor de Carretera'),
(8, 3, 15, 'IJSIDHISD', 'RENAULT', '76', '', '', '', '', '', '', '2010-05-15', '', '963 YHD', '2010-05-15 18:50:11', '2010-05-15 18:50:11', 'SEDAN'),
(9, 1, 24, '', '', '', '', '', '', '', '', '', '2010-05-15', '', '9873 JHSD', '2010-05-15 18:50:36', '2010-05-15 18:50:36', ''),
(10, 2, 25, '', '', '', '', '', '', '', '', '', '2010-05-15', '', '933 SDO', '2010-05-15 18:50:52', '2010-05-15 18:50:52', ''),
(11, 2, 24, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'POD 233', '2010-05-15 18:51:09', '2010-05-15 18:51:09', ''),
(12, 2, 25, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'OKD 3454', '2010-05-15 18:51:20', '2010-05-15 18:51:20', ''),
(13, 3, 26, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'III 983', '2010-05-15 18:51:35', '2010-05-15 18:51:35', ''),
(14, 3, 21, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'UHD 222', '2010-05-15 18:52:16', '2010-05-15 18:52:16', ''),
(15, 3, 21, '', '', '', '', '', '', '', '', '', '2010-05-15', '', 'jdk 653', '2010-05-15 18:58:43', '2010-05-17 00:40:05', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehicle_types`
--

CREATE TABLE IF NOT EXISTS `vehicle_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `image` longblob,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `vehicle_types`
--

INSERT INTO `vehicle_types` (`id`, `name`, `image`, `created`, `modified`) VALUES
(1, 'Moto', NULL, '2010-05-12 01:01:49', '2010-05-12 01:01:49'),
(2, 'Auto', NULL, '2010-05-12 01:01:56', '2010-05-12 01:01:56'),
(3, 'Maquinaria', NULL, '2010-05-12 01:02:02', '2010-05-12 01:02:02');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `fk_localidades_departamentos1` FOREIGN KEY (`county_id`) REFERENCES `counties` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `counties`
--
ALTER TABLE `counties`
  ADD CONSTRAINT `fk_departamentos_jurisdicciones1` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `customer_homes`
--
ALTER TABLE `customer_homes`
  ADD CONSTRAINT `fk_domicilios_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `customer_legals`
--
ALTER TABLE `customer_legals`
  ADD CONSTRAINT `fk_tipo_personas_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `customer_naturals`
--
ALTER TABLE `customer_naturals`
  ADD CONSTRAINT `fk_clientes_estado_civiles` FOREIGN KEY (`marital_status_id`) REFERENCES `marital_statuses` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tipo_personas_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `f02s`
--
ALTER TABLE `f02s`
  ADD CONSTRAINT `fk_f02s_representatives1` FOREIGN KEY (`representative_id`) REFERENCES `representatives` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_f02s_vehicles1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `f12s`
--
ALTER TABLE `f12s`
  ADD CONSTRAINT `fk_f12_vehicles1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `field_coordenates`
--
ALTER TABLE `field_coordenates`
  ADD CONSTRAINT `fk_field_type_fcreators1` FOREIGN KEY (`field_creator_id`) REFERENCES `field_creators` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_field_type_field_types1` FOREIGN KEY (`field_type_id`) REFERENCES `field_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `identifications`
--
ALTER TABLE `identifications`
  ADD CONSTRAINT `fk_identificaciones_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_identifications_identification_types1` FOREIGN KEY (`identification_type_id`) REFERENCES `identification_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `representatives`
--
ALTER TABLE `representatives`
  ADD CONSTRAINT `fk_apoderados_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_representatives_identification_types1` FOREIGN KEY (`identification_type_id`) REFERENCES `identification_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `spouses`
--
ALTER TABLE `spouses`
  ADD CONSTRAINT `fk_spouses_customer_naturals` FOREIGN KEY (`customer_natural_id`) REFERENCES `customer_naturals` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_spouses_identification_types` FOREIGN KEY (`identification_type_id`) REFERENCES `identification_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `fk_vehicles_vehicle_type1` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vehiculos_clientes1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
